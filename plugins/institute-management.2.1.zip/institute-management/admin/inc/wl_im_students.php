<?php
defined( 'ABSPATH' ) or die();
require_once( WL_IM_PLUGIN_DIR_PATH . '/admin/inc/helpers/WL_IM_Helper.php' );
require_once( WL_IM_PLUGIN_DIR_PATH . '/admin/inc/controllers/WL_IM_Student.php' );

$wlim_active_courses = WL_IM_Helper::get_active_courses();
?>

<div class="container-fluid wl_im_container">
	<!-- row 1 -->
	<div class="row">
		<div class="col">
			<!-- main header content -->
			<h1 class="display-4 text-center"><span class="border-bottom"><i class="fa fa-users"></i> <?php _e( 'Students', WL_IM_DOMAIN ); ?></span></h1>
			<div class="mt-3 alert alert-info text-center" role="alert">
				<?php _e( 'Here, you can either add a new student or edit existing students.', WL_IM_DOMAIN ); ?>
			</div>
			<!-- end main header content -->
		</div>
	</div>
	<!-- end - row 1 -->

	<!-- row 2 -->
	<div class="row">
		<div class="card col">
			<div class="card-header">
				<!-- card header content -->
				<div class="row">
					<div class="col-md-9 col-xs-12">
						<div class="h3"><?php _e( 'Manage Students', WL_IM_DOMAIN ); ?></div>
					</div>
					<div class="col-md-3 col-xs-12">
						<button type="button" class="btn btn-outline-primary float-right add-student" data-toggle="modal" data-target="#add-student"  data-backdrop="static" data-keyboard="false"><i class="fa fa-plus"></i> <?php _e( 'Add New Student', WL_IM_DOMAIN ); ?>
						</button>
					</div>
				</div>
				<!-- end - card header content -->
			</div>
			<div class="card-body">
				<!-- card body content -->
				<div class="row">
					<div class="col">
						<table class="table table-hover table-striped table-bordered" id="student-table">
							<thead>
								<tr>
						        	<th scope="col"><?php _e( 'Enrollment ID', WL_IM_DOMAIN ); ?></th>
						        	<th scope="col"><?php _e( 'Course', WL_IM_DOMAIN ); ?></th>
						        	<th scope="col"><?php _e( 'Batch', WL_IM_DOMAIN ); ?></th>
						        	<th scope="col"><?php _e( 'Duration', WL_IM_DOMAIN ); ?></th>
						        	<th scope="col"><?php _e( 'First Name', WL_IM_DOMAIN ); ?></th>
						        	<th scope="col"><?php _e( 'Last Name', WL_IM_DOMAIN ); ?></th>
						        	<th scope="col"><?php _e( 'Fees Payable', WL_IM_DOMAIN ); ?></th>
						        	<th scope="col"><?php _e( 'Fees Paid', WL_IM_DOMAIN ); ?></th>
						        	<th scope="col"><?php _e( 'Fees Status', WL_IM_DOMAIN ); ?></th>
						        	<th scope="col"><?php _e( 'Phone', WL_IM_DOMAIN ); ?></th>
						        	<th scope="col"><?php _e( 'Email', WL_IM_DOMAIN ); ?></th>
						        	<th scope="col"><?php _e( 'Is Active', WL_IM_DOMAIN ); ?></th>
						        	<th scope="col"><?php _e( 'Added By', WL_IM_DOMAIN ); ?></th>
						        	<th scope="col"><?php _e( 'Registration Date', WL_IM_DOMAIN ); ?></th>
						        	<th scope="col"><?php _e( 'Completion Date', WL_IM_DOMAIN ); ?></th>
						        	<th scope="col"><?php _e( 'Edit', WL_IM_DOMAIN ); ?></th>
								</tr>
							</thead>
						</table>
					</div>
				</div>
				<!-- end - card body content -->
			</div>
		</div>
	</div>
	<!-- end - row 2 -->
</div>

<!-- add new student modal -->
<div class="modal fade" id="add-student" tabindex="-1" role="dialog" aria-labelledby="add-student-label" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="add-student-label"><?php _e( 'Add New Student', WL_IM_DOMAIN ); ?></h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body pr-4 pl-4">
				<form id="wlim-add-student-form">
					<?php $nonce = wp_create_nonce( 'add-student' ); ?>
	                <input type="hidden" name="add-student" value="<?php echo $nonce; ?>">
	                <div class="wlim-add-student-form-fields">
						<div class="form-check pl-0 pb-3 mb-2 border-bottom">
							<input name="from_enquiry" class="position-static mt-0 form-check-input" type="checkbox" id="wlim-student-from_enquiry">
							<label class="form-check-label" for="wlim-student-from_enquiry">
							<?php _e( 'From Enquiry?', WL_IM_DOMAIN ); ?>
							</label>
						</div>
		                <div id="wlim-add-student-from-enquiries"></div>
		                <div id="wlim-add-student-form-fields">
			                <?php WL_IM_Student::render_add_student_form( $wlim_active_courses ); ?>
						</div>
					</div>
				</form>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-secondary" data-dismiss="modal"><?php _e( 'Cancel', WL_IM_DOMAIN ); ?></button>
				<button type="button" class="btn btn-primary add-student-submit"><?php _e( 'Add New Student', WL_IM_DOMAIN ); ?></button>
			</div>
		</div>
	</div>
</div>
<!-- end - add new student modal -->

<!-- update student modal -->
<div class="modal fade" id="update-student" tabindex="-1" role="dialog" aria-labelledby="update-student-label" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="update-student-label"><?php _e( 'Update Student', WL_IM_DOMAIN ); ?></h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body pr-4 pl-4" id="fetch_student"></div>
			<div class="modal-footer">
				<button type="button" class="btn btn-secondary" data-dismiss="modal"><?php _e( 'Cancel', WL_IM_DOMAIN ); ?></button>
				<button type="button" class="btn btn-primary update-student-submit"><?php _e( 'Update Student', WL_IM_DOMAIN ); ?></button>
			</div>
		</div>
	</div>
</div>
<!-- end - update student modal -->