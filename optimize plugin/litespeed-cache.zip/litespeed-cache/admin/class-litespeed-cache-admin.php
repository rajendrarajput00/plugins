<?php
/**
 * ONLY for WHM plugin old version backward compatibility @Aug/2/2017
 */


require_once dirname(__FILE__) . '/litespeed-cache-admin.class.php' ;