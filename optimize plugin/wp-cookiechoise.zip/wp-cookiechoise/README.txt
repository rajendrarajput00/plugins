=== Plugin Name ===
Contributors: smoo1337
Donate link: http://conversion-junkies.de
Tags: cookies, privacy
Requires at least: 3.5.1
Tested up to: 4.3.2
Stable tag: 1.1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

The plugin uses the google Cookiechoice.org guideline and javascript library.
Its handle the integration easy for all wordpress users.

*** Rating***
Please let us know when you have problems - befor you rate the plugin.
If the plugin helps you. feel free to rate it with 5 stars.

***NO WARRANTY***
We change the original cookiechoice.js 
The cookie was set to the page not to the domain.
Now we set the cookie domain wide.

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload the pluginfolder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Go to Plugins -> CookieChoice
1. Fill out the form and active the integration.
1. show the cookie information and get happy

== Frequently Asked Questions ==


== Screenshots ==


== Changelog ==

= 1.0 =
* domainwide cookie
* Setting only for admins

= 1.0 =
* first version starts