<?php
// You shouldn't be here.